--
project name: `illlustrations`,
author: `vijay verma`,
version: 1.0.3,
author_url: `https://vijayverma.co`
twitter: `https://twitter.com/realvjy`
description: `Open source illlustrations kit`,
siteUrl: `https://illlustrations.co/`,
license: "The MIT License - Free for both personal and commercial use"
repository: https://github.com/realvjy/illlustrations.git
Update: 2 Feb 2020 - Added 20 More illustrations
Update: 24 March 2020 - COVID 19 & WFH illustrations
--
Large set of opensource illustrations. You can use completely free and without attribution. You can use to design beautiful webpage, mobile app and presentations. Tweet your feedback to @realvjy

For color inspiration: uihues.com
Printable mockups: uiprint.co
Buy me a coffee: https://www.buymeacoffee.com/realvjy



Thanks you for downloading
✌️
